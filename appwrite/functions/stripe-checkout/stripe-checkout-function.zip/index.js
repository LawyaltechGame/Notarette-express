const sdk = require('node-appwrite');
const stripe = require('stripe');

/*
  'req' variable has:
    'headers' - object with request headers
    'payload' - object with request body data
    'variables' - object with function variables

  'res' variable has:
    'send(text, status)' - function to return text response. Status code defaults to 200
    'json(obj, status)' - function to return JSON response. Status code defaults to 200
  
  If an error is thrown, a response with code 500 will be returned.
*/

module.exports = async function (req, res) {
  try {
    console.log('Function started with payload:', req.payload);
    
    // Initialize Stripe with your secret key
    const stripeSecretKey = req.variables.STRIPE_SECRET_KEY;
    if (!stripeSecretKey) {
      console.error('STRIPE_SECRET_KEY not found in environment variables');
      return res.json({ 
        error: 'STRIPE_SECRET_KEY environment variable is not set',
        details: 'Please set the STRIPE_SECRET_KEY in your Appwrite Function environment variables'
      }, 500);
    }
    
    console.log('Stripe secret key found, initializing client...');
    const stripeClient = stripe(stripeSecretKey);
    
    // Parse the request payload
    let payload;
    try {
      payload = JSON.parse(req.payload);
      console.log('Parsed payload:', payload);
    } catch (parseError) {
      console.error('Failed to parse payload:', parseError);
      return res.json({ 
        error: 'Invalid JSON payload',
        details: parseError.message 
      }, 400);
    }
    
    const { items, successUrl, cancelUrl, metadata } = payload;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.error('No items provided in payload');
      return res.json({ 
        error: 'No items provided for checkout',
        details: 'Items array is required and must not be empty'
      }, 400);
    }
    
    console.log('Processing items:', items);
    
    // Calculate total amount and prepare line items
    let totalAmount = 0;
    const lineItems = [];
    
    // For testing purposes, we'll use a simple approach with unit amounts
    // In production, you should use actual Stripe price IDs
    for (const item of items) {
      console.log('Processing item:', item);
      
      // Service price mapping (in cents)
      const servicePrices = {
        'power-of-attorney': 1000, // ₹10.00 in cents
        'certified-copy-document': 2000, // ₹20.00 in cents
        'certified-copy-passport-id': 2500, // $25.00 in cents
        'company-formation-documents': 5000, // $50.00 in cents
        'apostille-services': 8000, // $80.00 in cents
        'document-translation-notarization': 6000, // $60.00 in cents
        'real-estate-document-notarization': 4500, // $45.00 in cents
        'estate-planning-document-notarization': 5500, // $55.00 in cents
      };
      
      const servicePrice = servicePrices[item.serviceId];
      if (!servicePrice) {
        console.error(`No price found for service: ${item.serviceId}`);
        return res.json({ 
          error: `No price found for service: ${item.serviceId}`,
          details: `Available services: ${Object.keys(servicePrices).join(', ')}`
        }, 400);
      }
      
      // For testing, we'll create line items with unit amounts instead of price IDs
      lineItems.push({
        price_data: {
          currency: item.serviceId.includes('passport') || item.serviceId.includes('company') || 
                   item.serviceId.includes('apostille') || item.serviceId.includes('translation') || 
                   item.serviceId.includes('real-estate') || item.serviceId.includes('estate') ? 'usd' : 'inr',
          product_data: {
            name: item.serviceId.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
            description: `Notarization service for ${item.serviceId.replace(/-/g, ' ')}`
          },
          unit_amount: servicePrice
        },
        quantity: item.quantity
      });
      
      totalAmount += servicePrice * item.quantity;
    }
    
    console.log('Line items prepared:', lineItems);
    console.log('Total amount:', totalAmount);
    
    // Determine currency based on the first service
    const currencyMapping = {
      'power-of-attorney': 'inr',
      'certified-copy-document': 'inr',
      'certified-copy-passport-id': 'usd',
      'company-formation-documents': 'usd',
      'apostille-services': 'usd',
      'document-translation-notarization': 'usd',
      'real-estate-document-notarization': 'usd',
      'estate-planning-document-notarization': 'usd',
    };
    
    const currency = currencyMapping[items[0].serviceId] || 'inr';
    console.log('Using currency:', currency);
    
    // Create Stripe Checkout Session
    console.log('Creating Stripe checkout session...');
    const session = await stripeClient.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: successUrl || `${req.headers.origin}/post-checkout?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl || `${req.headers.origin}/services`,
      metadata: metadata || {},
      currency: currency,
      customer_email: req.variables.CUSTOMER_EMAIL || undefined,
    });
    
    console.log('Stripe session created successfully:', session.id);
    
    // Return the checkout URL
    return res.json({
      url: session.url,
      sessionId: session.id,
      amount: totalAmount,
      currency: currency
    });
    
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return res.json({ 
      error: 'Failed to create checkout session',
      details: error.message,
      stack: error.stack
    }, 500);
  }
};
